package gajendrasinghrathore.itunessongslist.utilities;


public class Constants {
    public static String baseURL = "https://itunes.apple.com/search?term=Michael+Jackson";
}
